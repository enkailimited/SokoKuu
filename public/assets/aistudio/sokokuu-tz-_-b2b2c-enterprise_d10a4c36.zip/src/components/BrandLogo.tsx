import sokoLogoImg from '../assets/images/sokokuu_brand_logo_1794837084241.jpg';

export function BrandLogo({
  size = 'md',
  showWordmark = true,
  subtitle,
}: {
  size?: 'sm' | 'md' | 'lg';
  showWordmark?: boolean;
  subtitle?: string;
}) {
  const sizeClass =
    size === 'sm' ? 'w-7 h-7' : size === 'lg' ? 'w-11 h-11' : 'w-9 h-9';

  return (
    <span className="inline-flex items-center gap-2.5 shrink-0">
      <img
        src={sokoLogoImg}
        alt="SokoKuu TZ"
        referrerPolicy="no-referrer"
        className={`${sizeClass} rounded-lg object-cover border border-slate-200/80 bg-white shrink-0`}
      />
      {showWordmark && (
        <span className="flex flex-col text-left leading-tight">
          <span className="text-base sm:text-lg font-bold tracking-tight text-slate-950 whitespace-nowrap">
            SokoKuu TZ
          </span>
          {subtitle && (
            <span className="text-[11px] font-mono text-slate-500 whitespace-nowrap">
              {subtitle}
            </span>
          )}
        </span>
      )}
    </span>
  );
}
