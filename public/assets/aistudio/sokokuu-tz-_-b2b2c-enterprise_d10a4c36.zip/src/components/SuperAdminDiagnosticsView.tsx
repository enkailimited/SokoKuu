import type { Locale } from '../data/i18n';
import { SuperAdminDashboardLayout } from './SuperAdminDashboardLayout';

export function SuperAdminDiagnosticsView({
  locale = 'en',
  authority,
}: {
  locale?: Locale;
  authority: string;
}) {
  return <SuperAdminDashboardLayout locale={locale} authority={authority} />;
}

