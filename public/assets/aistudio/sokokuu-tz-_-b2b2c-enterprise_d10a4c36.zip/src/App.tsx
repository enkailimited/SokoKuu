import { useEffect, useRef, useState } from 'react';
import { ChevronDown, Languages, LogOut, Settings, UserCog } from 'lucide-react';
import type { Locale } from './data/i18n';
import { DataSaverProvider } from './context/DataSaverContext';
import { HybridModeProvider } from './context/HybridModeContext';
import {
  MODE_LABELS,
  ROLE_LABELS,
  SEED_PLATFORM_ACCOUNTS,
  type PlatformRole,
  type UserProfile,
} from './types/auth';
import { AuthPortalView } from './components/AuthPortalView';
import { BrandLogo } from './components/BrandLogo';
import { ConsumerDashboardView } from './components/ConsumerDashboardView';
import { RetailerShoppingView, type RetailerTab } from './components/RetailerShoppingView';
import { WholesalerOperationsView } from './components/WholesalerOperationsView';
import { MobileDriverReceiptCard } from './components/MobileDriverReceiptCard';
import { SuperAdminDiagnosticsView } from './components/SuperAdminDiagnosticsView';
import { ProfileEditView, SettingsView } from './components/AccountPages';
import { OfflineIndicator } from './components/OfflineIndicator';
import { PWAInstallButton } from './components/PWAInstallButton';
import { isTenantGeospatialMapEnabled } from './lib/sokoManagedState';

type ActiveAccountPage = 'DASHBOARD' | 'PROFILE' | 'SETTINGS';

const SESSION_STORAGE_KEY = 'sokokuu_active_role_v1';
const ACCOUNTS_STORAGE_KEY = 'sokokuu_accounts_v1';
const LOCALE_STORAGE_KEY = 'sokokuu_locale_v1';
const RETAILER_TAB_STORAGE_KEY = 'sokokuu_retailer_tab_v1';

function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return 'SK';
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
}

export default function App() {
  return (
    <DataSaverProvider>
      <HybridModeProvider>
        <SinglePlatformShell />
      </HybridModeProvider>
    </DataSaverProvider>
  );
}

function SinglePlatformShell() {
  const [locale, setLocaleState] = useState<Locale>(() => {
    try {
      const saved = window.localStorage.getItem(LOCALE_STORAGE_KEY);
      if (saved === 'en' || saved === 'sw') {
        return saved;
      }
    } catch {
      // ignore storage errors
    }
    return 'sw';
  });

  const setLocale = (nextOrUpdater: Locale | ((prev: Locale) => Locale)) => {
    setLocaleState((prev) => {
      const next = typeof nextOrUpdater === 'function' ? nextOrUpdater(prev) : nextOrUpdater;
      try {
        window.localStorage.setItem(LOCALE_STORAGE_KEY, next);
      } catch {
        // ignore storage errors
      }
      return next;
    });
  };

  useEffect(() => {
    document.documentElement.lang = locale;
  }, [locale]);

  const [accounts, setAccounts] = useState<Record<PlatformRole, UserProfile>>(() => {
    try {
      const saved = window.localStorage.getItem(ACCOUNTS_STORAGE_KEY);
      if (saved) {
        return { ...SEED_PLATFORM_ACCOUNTS, ...JSON.parse(saved) };
      }
    } catch {
      // ignore storage errors
    }
    return SEED_PLATFORM_ACCOUNTS;
  });

  const [activeRole, setActiveRole] = useState<PlatformRole | null>(() => {
    try {
      const savedRole = window.localStorage.getItem(SESSION_STORAGE_KEY) as PlatformRole | null;
      if (savedRole && savedRole in SEED_PLATFORM_ACCOUNTS) {
        return savedRole;
      }
    } catch {
      // ignore storage errors
    }
    return null;
  });

  const [activePage, setActivePage] = useState<ActiveAccountPage>('DASHBOARD');
  const [retailerTab, setRetailerTabState] = useState<RetailerTab>(() => {
    try {
      const savedTab = window.localStorage.getItem(RETAILER_TAB_STORAGE_KEY);
      if (
        savedTab === 'pos_register' ||
        savedTab === 'inventory_shelf' ||
        savedTab === 'core_engine' ||
        savedTab === 'proximity_map'
      ) {
        if (savedTab === 'proximity_map' && !isTenantGeospatialMapEnabled('ret-sinza-01')) {
          return 'pos_register';
        }
        return savedTab;
      }
    } catch {
      // ignore storage errors
    }
    return 'pos_register';
  });

  const setRetailerTab = (tab: RetailerTab) => {
    setRetailerTabState(tab);
    try {
      window.localStorage.setItem(RETAILER_TAB_STORAGE_KEY, tab);
    } catch {
      // ignore storage errors
    }
  };

  const [profileMenuOpen, setProfileMenuOpen] = useState<boolean>(false);
  const [mapsQuotaExceeded, setMapsQuotaExceeded] = useState<boolean>(false);
  const [retailerMapEnabled, setRetailerMapEnabled] = useState<boolean>(() =>
    isTenantGeospatialMapEnabled('ret-sinza-01')
  );
  const menuContainerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const handleQuotaExceeded = () => setMapsQuotaExceeded(true);
    const handleGeoToggle = () => {
      const enabled = isTenantGeospatialMapEnabled('ret-sinza-01');
      setRetailerMapEnabled(enabled);
      if (!enabled && retailerTab === 'proximity_map') {
        setRetailerTab('core_engine');
      }
    };

    window.addEventListener('gmp-quota-exceeded', handleQuotaExceeded);
    window.addEventListener('sokokuu:geospatial-toggle-updated', handleGeoToggle);
    window.addEventListener('storage', handleGeoToggle);
    return () => {
      window.removeEventListener('gmp-quota-exceeded', handleQuotaExceeded);
      window.removeEventListener('sokokuu:geospatial-toggle-updated', handleGeoToggle);
      window.removeEventListener('storage', handleGeoToggle);
    };
  }, [retailerTab]);

  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent) => {
      if (
        menuContainerRef.current &&
        !menuContainerRef.current.contains(event.target as Node)
      ) {
        setProfileMenuOpen(false);
      }
    };
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setProfileMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    document.addEventListener('keydown', handleEscape);
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
      document.removeEventListener('keydown', handleEscape);
    };
  }, []);

  const handleSignIn = (role: PlatformRole) => {
    setActiveRole(role);
    setActivePage('DASHBOARD');
    setRetailerTab('pos_register');
    setProfileMenuOpen(false);
    try {
      window.localStorage.setItem(SESSION_STORAGE_KEY, role);
    } catch {
      // ignore storage errors
    }
  };

  const handleLogout = () => {
    setActiveRole(null);
    setActivePage('DASHBOARD');
    setProfileMenuOpen(false);
    try {
      window.localStorage.removeItem(SESSION_STORAGE_KEY);
    } catch {
      // ignore storage errors
    }
  };

  const handleSaveProfile = (updated: UserProfile) => {
    setAccounts((prev) => {
      const next = { ...prev, [updated.role]: updated };
      try {
        window.localStorage.setItem(ACCOUNTS_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // ignore storage errors
      }
      return next;
    });
  };

  if (!activeRole) {
    return (
      <AuthPortalView
        locale={locale}
        onToggleLocale={() => setLocale((prev) => (prev === 'en' ? 'sw' : 'en'))}
        accounts={accounts}
        onSignIn={handleSignIn}
      />
    );
  }

  const isSw = locale === 'sw';
  const activeProfile = accounts[activeRole];

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col">
      {mapsQuotaExceeded && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
          <span>
            Google Maps Platform quota reached. If you are the app owner, visit{' '}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-950 hover:text-amber-800"
            >
              maps developer site
            </a>{' '}
            for instructions to update your account.
          </span>
        </div>
      )}
      {/* ONE Single Top AppBar with integrated navigation tabs */}
      <header className="sticky top-0 z-40 bg-white border-b border-slate-100">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4 sm:gap-8">
            <button
              type="button"
              onClick={() => {
                setActivePage('DASHBOARD');
                setProfileMenuOpen(false);
              }}
              className="whitespace-nowrap shrink-0 hover:opacity-90 transition-opacity cursor-pointer"
            >
              <BrandLogo size="md" />
            </button>

            {/* Top AppBar Navigation Tabs (Visible on mobile and desktop) */}
            <nav className="flex items-center gap-3 sm:gap-6 text-xs sm:text-sm font-medium text-slate-600 overflow-x-auto no-scrollbar py-2">
              {activeProfile.role === 'RETAILER' ? (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      setRetailerTab('pos_register');
                      setActivePage('DASHBOARD');
                    }}
                    className={`whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
                      activePage === 'DASHBOARD' && retailerTab === 'pos_register'
                        ? 'text-slate-950 underline underline-offset-8 decoration-2 decoration-emerald-600 font-semibold'
                        : 'hover:text-slate-900'
                    }`}
                  >
                    {isSw ? 'POS Mauzo' : 'POS Sales'}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setRetailerTab('inventory_shelf');
                      setActivePage('DASHBOARD');
                    }}
                    className={`whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
                      activePage === 'DASHBOARD' && retailerTab === 'inventory_shelf'
                        ? 'text-slate-950 underline underline-offset-8 decoration-2 decoration-emerald-600 font-semibold'
                        : 'hover:text-slate-900'
                    }`}
                  >
                    {isSw ? 'Hifadhi & Bidhaa' : 'Inventory & Catalogs'}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setRetailerTab('core_engine');
                      setActivePage('DASHBOARD');
                    }}
                    className={`whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
                      activePage === 'DASHBOARD' && retailerTab === 'core_engine'
                        ? 'text-slate-950 underline underline-offset-8 decoration-2 decoration-emerald-600 font-semibold'
                        : 'hover:text-slate-900'
                    }`}
                  >
                    {isSw ? 'Sokoni & Oda' : 'Sokoni Marketplace'}
                  </button>

                  {retailerMapEnabled && (
                    <button
                      type="button"
                      onClick={() => {
                        setRetailerTab('proximity_map');
                        setActivePage('DASHBOARD');
                      }}
                      className={`whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
                        activePage === 'DASHBOARD' && retailerTab === 'proximity_map'
                          ? 'text-slate-950 underline underline-offset-8 decoration-2 decoration-emerald-600 font-semibold'
                          : 'hover:text-slate-900'
                      }`}
                    >
                      {isSw ? 'Ramani (GIS)' : 'Proximity Map'}
                    </button>
                  )}
                </>
              ) : (
                <button
                  type="button"
                  onClick={() => setActivePage('DASHBOARD')}
                  className={`whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
                    activePage === 'DASHBOARD'
                      ? 'text-slate-950 underline underline-offset-8 decoration-2 decoration-emerald-600 font-semibold'
                      : 'hover:text-slate-900'
                  }`}
                >
                  {isSw ? 'Dashibodi' : 'Dashboard'}
                </button>
              )}

              <button
                type="button"
                onClick={() => setActivePage('PROFILE')}
                className={`whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
                  activePage === 'PROFILE'
                    ? 'text-slate-950 underline underline-offset-8 decoration-2 decoration-emerald-600 font-semibold'
                    : 'hover:text-slate-900'
                }`}
              >
                {isSw ? 'Wasifu' : 'Profile'}
              </button>
              <button
                type="button"
                onClick={() => setActivePage('SETTINGS')}
                className={`whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
                  activePage === 'SETTINGS'
                    ? 'text-slate-950 underline underline-offset-8 decoration-2 decoration-emerald-600 font-semibold'
                    : 'hover:text-slate-900'
                }`}
              >
                {isSw ? 'Mipangilio' : 'Settings'}
              </button>
            </nav>
          </div>

          {/* Top-Right PWA Install + Language Switcher + Profile Section */}
          <div className="flex items-center gap-2 shrink-0">
            <PWAInstallButton locale={locale} />

            <button
              type="button"
              onClick={() => setLocale((prev) => (prev === 'en' ? 'sw' : 'en'))}
              title={isSw ? 'Switch to English' : 'Badili kwenda Kiswahili'}
              className="min-h-[40px] px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 flex items-center gap-1.5 text-xs font-semibold text-slate-700 cursor-pointer transition-colors"
            >
              <Languages className="w-3.5 h-3.5 text-emerald-600 shrink-0" aria-hidden="true" />
              <span>{isSw ? 'SW' : 'EN'}</span>
            </button>

            <div className="relative shrink-0" ref={menuContainerRef}>
              <button
                type="button"
                onClick={() => setProfileMenuOpen((prev) => !prev)}
                aria-expanded={profileMenuOpen}
                aria-haspopup="menu"
                className="min-h-[40px] px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 flex items-center gap-2.5 cursor-pointer transition-colors"
              >
              <div className="w-7 h-7 rounded-full bg-emerald-600 text-white font-mono text-xs font-bold flex items-center justify-center shrink-0">
                {getInitials(activeProfile.fullName)}
              </div>
              <div className="text-left hidden sm:block max-w-[140px]">
                <div className="text-xs font-semibold text-slate-900 truncate">
                  {activeProfile.fullName}
                </div>
                <div className="text-[10px] text-slate-500 truncate">
                  {isSw ? ROLE_LABELS[activeProfile.role].sw : ROLE_LABELS[activeProfile.role].en}
                </div>
              </div>
              <ChevronDown className="w-4 h-4 text-slate-500 shrink-0" aria-hidden="true" />
            </button>

            {profileMenuOpen && (
              <div
                role="menu"
                className="absolute right-0 mt-2 w-72 bg-white border border-slate-200 rounded-lg shadow-lg overflow-hidden z-50"
              >
                <div className="px-4 py-3 border-b border-slate-100 bg-slate-50/70 space-y-0.5">
                  <div className="text-sm font-bold text-slate-900 truncate">
                    {activeProfile.fullName}
                  </div>
                  <div className="text-xs text-slate-600 truncate">
                    {activeProfile.businessLabel}
                  </div>
                  <div className="text-[11px] font-mono text-emerald-700 truncate">
                    {isSw ? ROLE_LABELS[activeProfile.role].sw : ROLE_LABELS[activeProfile.role].en} ·{' '}
                    {isSw ? MODE_LABELS[activeProfile.mode].sw : MODE_LABELS[activeProfile.mode].en}
                  </div>
                </div>

                <div className="p-1.5 space-y-0.5">
                  <button
                    type="button"
                    role="menuitem"
                    onClick={() => {
                      setActivePage('PROFILE');
                      setProfileMenuOpen(false);
                    }}
                    className="w-full min-h-[42px] px-3 py-2 text-left text-xs font-medium text-slate-700 hover:bg-slate-50 hover:text-slate-900 rounded-md flex items-center gap-2.5 cursor-pointer"
                  >
                    <UserCog className="w-4 h-4 text-emerald-600 shrink-0" aria-hidden="true" />
                    <span>
                      {isSw
                        ? 'Wasifu (Sasisha Taarifa Zako)'
                        : 'Profile (Update Information)'}
                    </span>
                  </button>

                  <button
                    type="button"
                    role="menuitem"
                    onClick={() => {
                      setActivePage('SETTINGS');
                      setProfileMenuOpen(false);
                    }}
                    className="w-full min-h-[42px] px-3 py-2 text-left text-xs font-medium text-slate-700 hover:bg-slate-50 hover:text-slate-900 rounded-md flex items-center gap-2.5 cursor-pointer"
                  >
                    <Settings className="w-4 h-4 text-slate-500 shrink-0" aria-hidden="true" />
                    <span>{isSw ? 'Mipangilio (Settings)' : 'Settings'}</span>
                  </button>

                  <div className="my-1 border-t border-slate-100" />

                  <button
                    type="button"
                    role="menuitem"
                    onClick={handleLogout}
                    className="w-full min-h-[42px] px-3 py-2 text-left text-xs font-semibold text-red-700 hover:bg-red-50 rounded-md flex items-center gap-2.5 cursor-pointer"
                  >
                    <LogOut className="w-4 h-4 text-red-600 shrink-0" aria-hidden="true" />
                    <span>{isSw ? 'Ondoka (Logout)' : 'Logout'}</span>
                  </button>
                </div>
              </div>
            )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Single-Role Dashboard Page or Account Subpage (Clean, without redundant title banners) */}
      <main
        className={
          activeProfile.role === 'SUPER_ADMIN' && activePage === 'DASHBOARD'
            ? 'flex-1 w-full flex flex-col'
            : 'flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl w-full mx-auto space-y-6'
        }
      >
        {activePage === 'DASHBOARD' && (
          <>
            {activeProfile.role === 'CONSUMER' && (
              <ConsumerDashboardView locale={locale} consumerWard={activeProfile.ward} />
            )}
            {activeProfile.role === 'RETAILER' && (
              <RetailerShoppingView
                locale={locale}
                activeTab={retailerTab}
                userRole="RETAILER"
                onRedirectToWorkspace={() => setRetailerTab('core_engine')}
              />
            )}
            {activeProfile.role === 'WHOLESALER' && (
              <WholesalerOperationsView locale={locale} />
            )}
            {activeProfile.role === 'DRIVER' && (
              <MobileDriverReceiptCard locale={locale} />
            )}
            {activeProfile.role === 'SUPER_ADMIN' && (
              <SuperAdminDiagnosticsView locale={locale} authority={activeProfile.role} />
            )}
          </>
        )}

        {activePage === 'PROFILE' && (
          <ProfileEditView
            locale={locale}
            profile={activeProfile}
            onSaveProfile={handleSaveProfile}
            onBackToDashboard={() => setActivePage('DASHBOARD')}
          />
        )}

        {activePage === 'SETTINGS' && (
          <SettingsView
            locale={locale}
            onSetLocale={setLocale}
            profile={activeProfile}
            onSaveProfile={handleSaveProfile}
            onBackToDashboard={() => setActivePage('DASHBOARD')}
          />
        )}
      </main>
      <OfflineIndicator locale={locale} />
    </div>
  );
}
